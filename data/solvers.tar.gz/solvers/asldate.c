long ASLdate_ASL = 20190605;
