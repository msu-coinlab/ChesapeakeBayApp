#include "funcadd.h"

 void
af_libnamesave_ASL(AmplExports *ae, const char *fullname, const char *name, int nlen)
{}
